package com.tpb.coinz

import android.app.Application

class App : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}